Thanks for downloading this template!

Template Name: Restaurantly
Template URL: https://bootstrapmade.com/restaurantly-restaurant-template/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
